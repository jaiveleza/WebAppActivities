<html>
 <head>
  <title>Jaiveleza B. Andales</title>
 </head>
 <body>
     <h1>Welcome to Autos Database </h1>     	
     	<a href="login.php" style="text-decoration:none">Please Log In<br><br></a>
        Attempt to go to 
        <a href="autos.php" style="text-decoration:none"> autos.php </a>
        without logging in - it should fail with an error message.<br><br>
        <a href="https://www.wa4e.com/assn/autosdb/" style="text-decoration:none"> Specification for the Application </a>				     
 </body>
</html>